SELECT * FROM Sis.Teams
